

public class Warmup {
    public static int backtrackingSearch(int[] arr, int x, int forward, int back, Stack myStack) {
        int counter = 0, ind = 0;
        while (ind < arr.length) {
            if (arr[ind] == x) {
                return ind;
            }
            else if (counter <= forward) {
                myStack.push(arr[ind]);
                counter++;
                ind++;
            }
            else {
                counter = back;
                while (counter > 0) {
                    ind--;
                    if (!myStack.pop().equals(arr[ind])) {
                        throw new IllegalArgumentException("The array has been changed"); //might be a redundant exception throw
                    }
                    counter--;
                }
            }
        }
    	return -1;
    }

    public static int consistentBinSearch(int[] arr, int x, Stack myStack) {
        int start = 0, end = arr.length-1, middle = (end + start)/2;
        if (x < arr[start] || x > arr[end]) {
            return -1;
        }
        while (start <= end) {
            int inconsistencies = Consistency.isConsistent(arr);
            if (inconsistencies != 0) {
                throw new IllegalArgumentException("The array has been changed"); //might be a redundant exception throw
            }
            if (arr[middle] == x) {
                return middle;
            }
            else if (arr[middle] < x) {
                start = middle;
                middle = (end + start)/2;
            }
            else {
                end = middle;
                middle = (end + start)/2;
            }
        }
    	return -1; // temporal return command to prevent compilation error
    }
    
}
