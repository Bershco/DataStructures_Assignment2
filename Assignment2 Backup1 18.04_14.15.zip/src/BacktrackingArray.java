import java.util.ArrayList;

public class BacktrackingArray implements Array<Integer>, Backtrack {
    private Stack stack;
    private int[] arr;
    private ArrayList<Integer> integerArrayList;

    // Do not change the constructor's signature
    public BacktrackingArray(Stack stack, int size) {
        this.stack = stack;
        arr = new int[size];
    }

    @Override
    public Integer get(int index){
        if (index < 0 || index > arr.length) throw new IllegalArgumentException();
    	return arr[index];
    }

    @Override
    public Integer search(int k) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == k) {
                return i;
            }
        }
    	return -1;
    }

    @Override
    public void insert(Integer x) {
        if (integerArrayList.size() < arr.length) {
            int[] input = {1, integerArrayList.size(), x};
            stack.push(input);
            integerArrayList.add(x);
        }
    }

    @Override
    public void delete(Integer index) {
        if (integerArrayList.size() > 0 && index < integerArrayList.size()) {
            int[] input = {0, index, integerArrayList.remove(index.intValue())};
            stack.push(input);
        }
    }

    @Override
    public Integer minimum() {
        if (integerArrayList.isEmpty()) {
            throw new IndexOutOfBoundsException("There's not a minimum number in the array, as it is empty.");
        }
        int min = integerArrayList.get(0);
        int minInd = 0;
        for (int i=0; i < integerArrayList.size(); i++) {
            if (integerArrayList.get(i) < min) {
                minInd = i;
            }
        }
    	return minInd;
    }

    @Override
    public Integer maximum() {
        if (integerArrayList.isEmpty()) {
            throw new IndexOutOfBoundsException("There's not a maximum number in the array, as it is empty.");
        }
        int max = integerArrayList.get(0);
        int maxInd = 0;
        for (int i = 0; i < integerArrayList.size(); i++) {
            if (integerArrayList.get(i) > max) {
                maxInd = i;
            }
        }
        return maxInd;
    }

    @Override
    public Integer successor(Integer index) {
        if (index < 0 || index > integerArrayList.size()) {
            throw new IndexOutOfBoundsException("You've gone above and beyond.");
        }
        if (integerArrayList.get(index).equals(maximum())) {
            throw new IndexOutOfBoundsException("There isn't a successor to the maximum number in the array by definition");
        }
        int curr = integerArrayList.get(index);
        int succ = Integer.MAX_VALUE;
        int succInd = -1;
        for (int i = 0; i < integerArrayList.size(); i++) {
            int iValue = integerArrayList.get(i);
            if (iValue > curr && iValue < succ) {
                succ = iValue;
                succInd = i;
            }
        }
        return succInd;
    }

    @Override
    public Integer predecessor(Integer index) {
        if (index < 0 || index > integerArrayList.size()) {
            throw new IndexOutOfBoundsException("You've gone above and beyond.");
        }
        if (integerArrayList.get(index).equals(minimum())) {
            throw new IndexOutOfBoundsException("There isn't a predecessor to the minimum number in the array by definition");
        }
        int curr = integerArrayList.get(index);
        int pred = Integer.MIN_VALUE;
        int predInd = -1;
        for (int i = 0; i < integerArrayList.size(); i++) {
            int iValue = integerArrayList.get(i);
            if (iValue < curr && iValue > pred) {
                pred = iValue;
                predInd = i;
            }
        }
        return predInd;
    }

    @Override
    public void backtrack() {
        int[] output = (int[]) stack.pop();
        if (output[0] == 0) {
            integerArrayList.add(output[1],output[2]);
        }
        else if (output[0] == 1) {
            integerArrayList.remove(output[1]);
        }
        else throw new IllegalArgumentException("You shouldn't have reached this point, you've done something illegal");
    }

    @Override
    public void retrack() {
		/////////////////////////////////////
		// Do not implement anything here! //
		/////////////////////////////////////
    }

    @Override
    public void print() {
        // TODO: implement your code here
    }
    
}
