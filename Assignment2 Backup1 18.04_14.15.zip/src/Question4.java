

public class Question4 {

	public static String section_i() {
		String answer = null;
		// answer = "Tetha(1)";
		// answer = "Tetha(log(log(n)))";
		// answer = "Tetha(log(n))";
		// answer = "Tetha(sqrt(n))"; // sqrt is an abbreviation for square root
		// answer = "Tetha(n)";
		// answer = "Tetha(n^(3/2))";
		// answer = "Tetha(nlog(n))";
		// answer = "Tetha(nlog^2(n))";
		// answer = "Tetha(n^2)";
		// answer = "Tetha(n^2*log(n))";
		// answer = "Tetha(n^3)";
		// answer = "Tetha(2^n)";
		return answer;
	}
	
	public static String section_ii() {
		String answer = null;
		// answer = "Tetha(1)";
		// answer = "Tetha(log(log(n)))";
		// answer = "Tetha(log(n))";
		// answer = "Tetha(sqrt(n))"; // sqrt is an abbreviation for square root
		// answer = "Tetha(n)";
		// answer = "Tetha(n^(3/2))";
		// answer = "Tetha(nlog(n))";
		// answer = "Tetha(nlog^2(n))";
		// answer = "Tetha(n^2)";
		// answer = "Tetha(n^2*log(n))";
		// answer = "Tetha(n^3)";
		// answer = "Tetha(2^n)";
		return answer;
	}

	public static String section_iii() {
		String answer = null;
		// answer = "Tetha(1)";
		// answer = "Tetha(log(log(n)))";
		// answer = "Tetha(log(n))";
		// answer = "Tetha(sqrt(n))"; // sqrt is an abbreviation for square root
		// answer = "Tetha(n)";
		// answer = "Tetha(n^(3/2))";
		// answer = "Tetha(nlog(n))";
		// answer = "Tetha(nlog^2(n))";
		// answer = "Tetha(n^2)";
		// answer = "Tetha(n^2*log(n))";
		// answer = "Tetha(n^3)";
		// answer = "Tetha(2^n)";
		return answer;
	}
	
	public static String section_iv() {
		String answer = null;
		// answer = "Tetha(1)";
		// answer = "Tetha(log(log(n)))";
		// answer = "Tetha(log(n))";
		// answer = "Tetha(sqrt(n))"; // sqrt is an abbreviation for square root
		// answer = "Tetha(n)";
		// answer = "Tetha(n^(3/2))";
		// answer = "Tetha(nlog(n))";
		// answer = "Tetha(nlog^2(n))";
		// answer = "Tetha(n^2)";
		// answer = "Tetha(n^2*log(n))";
		// answer = "Tetha(n^3)";
		// answer = "Tetha(2^n)";
		return answer;
	}
	
	public static String section_v() {
		String answer = null;
		// answer = "No additional memory is needed";
		// answer = "O(1)";
		// answer = "O(log(log(n)))";
		// answer = "O(log(n))";
		// answer = "O(sqrt(n))"; // sqrt is an abbreviation for square root
		// answer = "O(n)";
		return answer;
	}
	
	public static String section_vi() {
		String answer = null;
		// answer = "No additional memory is needed";
		// answer = "O(1)";
		// answer = "O(log(log(n)))";
		// answer = "O(log(n))";
		// answer = "O(sqrt(n))"; // sqrt is an abbreviation for square root
		// answer = "O(n)";
		return answer;
	}
	
}
