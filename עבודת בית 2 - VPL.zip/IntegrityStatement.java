

public class IntegrityStatement {

	public static String signature() {
		// change the returned value to your name/s, for example: "John Doe" if submit alone, or "John Doe and Ploni Almoni" if you submit in pair
		return null;
	}
	
}
