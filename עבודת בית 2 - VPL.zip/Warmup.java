

public class Warmup {
    public static int backtrackingSearch(int[] arr, int x, int forward, int back, Stack myStack) {
        // TODO: implement your code here
    	return -987; // temporal return command to prevent compilation error 
    }

    public static int consistentBinSearch(int[] arr, int x, Stack myStack) {
        // TODO: implement your code here
    	
    	// Your implementation should contain a this line:
    	int inconsistencies = Consistency.isConsistent(arr);
    	
    	return -987; // temporal return command to prevent compilation error
    }
    
}
